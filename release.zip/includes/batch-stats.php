<?php
/**
 * 批量预取仓库统计数据（Star/Fork/最后更新时间）
 * 
 * 策略：
 * - 使用 curl_multi 并发获取所有仓库数据（GitHub API repos 端点返回完整信息）
 * - 文件缓存 12 小时，避免频繁请求（未认证 60/hr 限额）
 * - 返回 owner/repo => [stars, forks, updated_at, stale] 的映射
 */

if (!defined('DATA_DIR')) {
    http_response_code(403);
    exit('Direct access not allowed');
}

/**
 * 批量获取仓库统计信息
 * 
 * @param array $repos [[owner, repo], ...] 二维数组
 * @param array $proxyUrls 代理 URL 列表
 * @param string|null $token GitHub Token（可选）
 * @return array [owner/repo => [stars, forks, updated_at, stale], ...]
 */
function batchFetchRepoStats($repos, $proxyUrls, $token = null) {
    if (empty($repos)) {
        return array();
    }

    $cacheKey = 'repo_stats_' . md5(json_encode($repos));
    $cached = file_cache_get($cacheKey);
    if ($cached !== null) {
        return $cached;
    }

    // 构建 API 请求（每个仓库对应 /repos/:owner/:repo 端点）
    $urls = array();
    $repoKeys = array();
    foreach ($repos as $r) {
        if (!isset($r['owner'], $r['repo'])) {
            continue;
        }
        $owner = $r['owner'];
        $repo = $r['repo'];
        $key = $owner . '/' . $repo;
        $apiUrl = 'https://api.github.com/repos/' . urlencode($owner) . '/' . urlencode($repo);
        $urls[] = $apiUrl;
        $repoKeys[] = $key;
    }

    if (empty($urls)) {
        return array();
    }

    // curl_multi 并发请求
    $responses = curl_multi_fetch($urls, $token);

    // 解析响应
    $stats = array();
    $successCount = 0;
    $hasValidData = false;

    foreach ($repoKeys as $idx => $key) {
        $body = isset($responses[$idx]) ? $responses[$idx] : null;
        $data = $body
            ? (function_exists('githubDecodeJsonBody') ? githubDecodeJsonBody($body) : json_decode($body, true))
            : null;

        if (!is_array($data) || !isset($data['stargazers_count'])) {
            // API 失败（限额/网络错误）：填充 null，不写入长效缓存
            $stats[$key] = array(
                'stars' => null,
                'forks' => null,
                'updated_at' => null,
                'stale' => false,
            );
            continue;
        }

        $successCount++;
        $hasValidData = true;
        $updatedAt = isset($data['updated_at']) ? $data['updated_at'] : null;
        $stale = false;
        if ($updatedAt !== null) {
            $updatedTime = strtotime($updatedAt);
            $stale = (time() - $updatedTime) > (30 * 86400); // 超过 30 天
        }

        $stats[$key] = array(
            'stars' => (int)$data['stargazers_count'],
            'forks' => (int)$data['forks_count'],
            'updated_at' => $updatedAt,
            'stale' => $stale,
        );
    }

    // 仅在至少一个仓库成功时写入缓存；全部失败则跳过缓存，避免 null 数据阻塞刷新
    if ($hasValidData) {
        $ttl = ($successCount >= max(1, intval(count($repoKeys) / 2))) ? 43200 : 300;
        file_cache_set($cacheKey, $stats, $ttl);
    }

    return $stats;
}

/**
 * curl_multi 并发抓取多个 URL（复用现有 includes/cache.php 逻辑）
 * 
 * @param array $urls URL 列表
 * @param string|null $token GitHub Token
 * @return array 响应体数组（按 URL 顺序）
 */
function curl_multi_fetch($urls, $token = null) {
    if (empty($urls)) {
        return array();
    }

    // 受限虚拟主机常缺少 curl_multi_* 或整个 cURL 扩展，
    // 此时退回顺序请求，仍有机会拿到部分仓库数据。
    if (!supports_multi_curl() || !function_exists('curl_init')) {
        return sequential_fetch($urls, $token);
    }

    $mh = curl_multi_init();
    if ($mh === false) {
        return sequential_fetch($urls, $token);
    }

    $handles = array();
    $userAgent = 'Legado-Resource-Accelerator/1.0';

    foreach ($urls as $idx => $url) {
        $fetchUrl = function_exists('githubMaybeRewriteUrl') ? githubMaybeRewriteUrl($url) : $url;
        $useToken = ($token !== null && trim($token) !== '')
            && (!function_exists('isGithubApiUrl') || isGithubApiUrl($fetchUrl));
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $fetchUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        if (defined('CURL_IPRESOLVE_V4') && strpos($fetchUrl, 'https://api.github.com/') === 0) {
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        }
        // 显式指定 CA bundle，避免某些发行版默认路径不存在导致 SSL 握手失败
        $caBundle = function_exists('getSystemCaBundlePath') ? getSystemCaBundlePath() : '';
        if ($caBundle !== '') {
            curl_setopt($ch, CURLOPT_CAINFO, $caBundle);
        }

        $headers = array(
            'Accept: application/vnd.github+json',
            'X-GitHub-Api-Version: 2022-11-28',
        );
        if ($useToken) {
            $headers[] = 'Authorization: Bearer ' . $token;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_multi_add_handle($mh, $ch);
        $handles[$idx] = $ch;
    }

    // 执行并发请求（带超时保护）
    $startTime = time();
    $timeout = 15; // 全局超时 15 秒
    do {
        $status = curl_multi_exec($mh, $active);
        if ($active) {
            curl_multi_select($mh, 0.1);
        }
        // 墙钟超时保护
        if ((time() - $startTime) > $timeout) {
            break;
        }
    } while ($active && $status === CURLM_OK);

    // 收集响应；直连失败的仓库再走 githubHttpGet 代理回退
    $responses = array();
    $needRetry = array();
    foreach ($handles as $idx => $ch) {
        $body = curl_multi_getcontent($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
        if ($httpCode === 200 && $body) {
            $responses[$idx] = $body;
        } else {
            $responses[$idx] = null;
            $needRetry[$idx] = $urls[$idx];
        }
    }
    curl_multi_close($mh);

    foreach ($needRetry as $idx => $url) {
        $result = githubHttpGet($url, 8, $token !== null && trim($token) !== '');
        if (isset($result['status']) && (int)$result['status'] === 200 && !empty($result['body'])) {
            $responses[$idx] = $result['body'];
        }
    }

    return $responses;
}

/**
 * 顺序抓取多个 URL（无 curl_multi 时的降级路径）
 *
 * 受限主机上单次首页请求可能只允许很短的执行时间，
 * 因此设置整体墙钟预算，超时后剩余仓库沿用静态快照。
 *
 * @param array $urls URL 列表
 * @param string|null $token GitHub Token
 * @return array 响应体数组（按 URL 顺序，失败为 null）
 */
function sequential_fetch($urls, $token = null) {
    $responses = array_fill(0, count($urls), null);

    if (githubHttpTransport() === 'none') {
        return $responses;
    }

    $includeToken = ($token !== null && trim($token) !== '');
    $startTime = microtime(true);
    $budget = 8.0; // 首页总预算，避免受限主机上串行请求拖慢渲染

    foreach ($urls as $idx => $url) {
        if ((microtime(true) - $startTime) > $budget) {
            break;
        }

        $result = githubHttpGet($url, 5, $includeToken);
        if ($result['status'] === 200 && $result['body'] !== null) {
            $responses[$idx] = $result['body'];
        }
    }

    return $responses;
}
